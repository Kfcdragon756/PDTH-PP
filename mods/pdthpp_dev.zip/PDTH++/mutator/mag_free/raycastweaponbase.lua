local module = ... or D:module("PDTH++")
local RaycastWeaponBase = module:hook_class("RaycastWeaponBase")

module:hook(RaycastWeaponBase, "on_reload", function(self)
	if self._setup.expend_ammo then
		if self._ammo_remaining_in_clip > 0 and self._ammo_remaining_in_clip ~= self._ammo_max_per_clip then
			self._ammo_total = self._ammo_total - self._ammo_remaining_in_clip
		end

		self._ammo_remaining_in_clip = math.min(self._ammo_total, self._ammo_max_per_clip)
		return
	end

	self._ammo_remaining_in_clip = self._ammo_max_per_clip
	self._ammo_total = self._ammo_max_per_clip
end)

module:hook(RaycastWeaponBase, "reload_speed_multiplier", function(self)
	local multiplier = self:weapon_tweak_data().reload_speed
	multiplier = multiplier * managers.player:synced_crew_bonus_upgrade_value("speed_reloaders", 1)
	multiplier = multiplier * 1.1
	return multiplier
end, true)
